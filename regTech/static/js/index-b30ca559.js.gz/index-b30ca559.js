import{d as e,c as n,o}from"./index-610f8130.js";const m=e({name:"Welcome",__name:"index",setup(t){return(a,c)=>(o(),n("h1",null,"Pure-Admin-Thin（国际化版本）"))}});export{m as default};
